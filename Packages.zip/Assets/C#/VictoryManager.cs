using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class VictoryManager : MonoBehaviour
{
    public static VictoryManager Instance;
    
    [Header("胜利UI")]
    public GameObject victoryPanel;
    public Text victoryText;
    public Button backToMenuButton;
    public Button restartButton;
    
    private bool isVictory = false;
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Debug.Log("VictoryManager 初始化完成");
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }
    
    void Start()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
        
        if (victoryPanel != null)
            victoryPanel.SetActive(false);
        
        if (backToMenuButton != null)
            backToMenuButton.onClick.AddListener(BackToMainMenu);
        
        if (restartButton != null)
            restartButton.onClick.AddListener(RestartGame);
    }
    
    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        isVictory = false;
        if (victoryPanel != null)
            victoryPanel.SetActive(false);
        Time.timeScale = 1f;
    }
    
    public void Victory()
    {
        if (isVictory) return;
        
        isVictory = true;
        Debug.Log("🎉 游戏胜利！");
        
        Time.timeScale = 0f;
        
        if (victoryPanel != null)
            victoryPanel.SetActive(true);
        
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }
    
    void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Game");
    }
    
    void BackToMainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }
    
    void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
    
    public bool IsVictory()
    {
        return isVictory;
    }
}