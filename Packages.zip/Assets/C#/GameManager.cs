using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public bool isPaused = false;
    public GameObject pauseMenuPanel;
    
    void Awake()
    {
        // 修复单例模式
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Debug.Log("GameManager 初始化完成");
        }
        else
        {
            Debug.Log("发现重复的 GameManager，销毁当前对象");
            Destroy(gameObject);
            return;  // 重要：销毁后不再执行后续代码
        }
    }
    
    void Start()
    {
        // 确保场景切换后正确设置
        SceneManager.sceneLoaded += OnSceneLoaded;
    }
    
    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        Debug.Log($"场景加载完成: {scene.name}");
        
        // 如果是游戏场景，确保时间恢复
        if (scene.name == "Game")
        {
            Time.timeScale = 1f;
            isPaused = false;
            
            // 重新查找并设置暂停面板
            if (pauseMenuPanel == null)
            {
                GameObject panel = GameObject.Find("PausePanel");
                if (panel != null)
                {
                    pauseMenuPanel = panel;
                    pauseMenuPanel.SetActive(false);
                }
            }
        }
        
        // 如果是主菜单场景，确保时间恢复
        if (scene.name == "MainMenu")
        {
            Time.timeScale = 1f;
            isPaused = false;
        }
    }
    
    void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
    
    void Update()
    {
        // 只在游戏场景处理暂停
        if (SceneManager.GetActiveScene().name != "Game") return;
        
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
                ResumeGame();
            else
                PauseGame();
        }
        
        if (Input.GetKeyDown(KeyCode.R))
        {
            RestartGame();
        }
    }
    
    public void PauseGame()
    {
        if (SceneManager.GetActiveScene().name != "Game") return;
        
        isPaused = true;
        Time.timeScale = 0f;
        
        if (pauseMenuPanel != null)
            pauseMenuPanel.SetActive(true);
        
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        
        Debug.Log("游戏暂停");
    }
    
    public void ResumeGame()
    {
        isPaused = false;
        Time.timeScale = 1f;
        
        if (pauseMenuPanel != null)
            pauseMenuPanel.SetActive(false);
        
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        
        Debug.Log("游戏继续");
    }
    
    public void RestartGame()
    {
        Debug.Log("重新开始游戏");
        Time.timeScale = 1f;
        isPaused = false;
        SceneManager.LoadScene("Game");
    }
    
    public void BackToMainMenu()
    {
        Debug.Log("返回主菜单");
        Time.timeScale = 1f;
        isPaused = false;
        SceneManager.LoadScene("MainMenu");
    }
    
    public void QuitGame()
    {
        Debug.Log("退出游戏");
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #elif !UNITY_WEBGL
            Application.Quit();
        #endif
    }
}