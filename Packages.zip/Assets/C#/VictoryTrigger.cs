using UnityEngine;

public class VictoryTrigger : MonoBehaviour
{
    [Header("胜利设置")]
    public string targetTag = "Player";
    public bool destroyOnTrigger = true;
    public GameObject victoryEffect;
    
    [Header("音效")]
    public AudioClip victorySound;
    
    private AudioSource audioSource;
    private bool triggered = false;
    
    void Start()
    {
        // 添加音频源组件（如果需要）
        if (victorySound != null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.playOnAwake = false;
        }
        
        Debug.Log($"胜利触发器已准备，等待玩家触碰");
    }
    
    void OnTriggerEnter(Collider other)
    {
        if (triggered) return;
        
        // 检查是否是玩家
        if (other.CompareTag(targetTag) || other.GetComponent<BallRollingWithCamera>() != null)
        {
            triggered = true;
            Debug.Log($"🎯 玩家触碰胜利方块！");
            
            // 播放胜利音效
            if (victorySound != null && audioSource != null)
            {
                audioSource.PlayOneShot(victorySound);
            }
            
            // 播放胜利特效
            if (victoryEffect != null)
            {
                GameObject effect = Instantiate(victoryEffect, transform.position, Quaternion.identity);
                Destroy(effect, 2f);
            }
            
            // 触发胜利
            if (VictoryManager.Instance != null)
            {
                VictoryManager.Instance.Victory();
            }
            else
            {
                Debug.LogError("找不到VictoryManager！请确保场景中有VictoryManager对象");
            }
            
            // 销毁触发器
            if (destroyOnTrigger)
            {
                Destroy(gameObject, 0.5f);
            }
        }
    }
    
    void OnDrawGizmos()
    {
        // 在编辑器中显示触发器范围
        Collider col = GetComponent<Collider>();
        if (col != null)
        {
            Gizmos.color = Color.yellow;
            if (col is BoxCollider)
            {
                BoxCollider box = (BoxCollider)col;
                Gizmos.DrawWireCube(transform.position + box.center, box.size);
            }
            else if (col is SphereCollider)
            {
                SphereCollider sphere = (SphereCollider)col;
                Gizmos.DrawWireSphere(transform.position + sphere.center, sphere.radius);
            }
        }
    }
}