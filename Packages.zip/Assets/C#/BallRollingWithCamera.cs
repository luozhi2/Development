using UnityEngine;

public class BallRollingWithCamera : MonoBehaviour
{
    [Header("移动参数")]
    public float moveForce = 15f;
    public float maxSpeed = 8f;
    public float jumpForce = 10f;

    [Header("跳跃系统")]
    public bool canJump = false;

    [Header("地面检测")]
    public LayerMask groundLayer = 1;

    [Header("相机跟随")]
    public Camera playerCamera;
    public Vector3 cameraOffset = new Vector3(0, 5, -8);
    public float cameraSmoothSpeed = 5f;

    private Rigidbody rb;
    private Vector3 moveDirection;
    private SphereCollider sphereCollider;
    private bool isOnGround = false;
    private int groundContactCount = 0;
    private float lastJumpTime = 0f;
    // 👇 添加这一行

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        sphereCollider = GetComponent<SphereCollider>();

        rb.drag = 0.5f;
        rb.angularDrag = 0.5f;
        rb.freezeRotation = false;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;

        if (playerCamera == null)
            playerCamera = Camera.main;

        canJump = true;
        isOnGround = true;
    }

    void Update()
    {

        // 输入
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 cameraForward = playerCamera.transform.forward;
        Vector3 cameraRight = playerCamera.transform.right;
        cameraForward.y = 0;
        cameraRight.y = 0;
        cameraForward.Normalize();
        cameraRight.Normalize();

        moveDirection = (cameraForward * vertical + cameraRight * horizontal).normalized;

        // 跳跃
        if (Input.GetButtonDown("Jump"))
        {
            if (canJump && isOnGround)
            {
                Jump();
            }
        }

        UpdateCamera();
}
    

    void FixedUpdate()
    {
        if (moveDirection != Vector3.zero)
        {
            rb.AddForce(moveDirection * moveForce, ForceMode.Force);
        }

        Vector3 horizontalVelocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        if (horizontalVelocity.magnitude > maxSpeed)
        {
            horizontalVelocity = horizontalVelocity.normalized * maxSpeed;
            rb.velocity = new Vector3(horizontalVelocity.x, rb.velocity.y, horizontalVelocity.z);
        }
    }

    void Jump()
    {
        rb.velocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);

        canJump = false;
        isOnGround = false;
        groundContactCount = 0;
        lastJumpTime = Time.time;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (((1 << collision.gameObject.layer) & groundLayer) != 0)
        {
            bool hasGroundContact = false;

            foreach (ContactPoint contact in collision.contacts)
            {
                if (contact.normal.y > 0.5f)
                {
                    hasGroundContact = true;
                    groundContactCount++;
                    break;
                }
            }

            if (hasGroundContact)
            {
                isOnGround = true;

                if (!canJump && Time.time > lastJumpTime + 0.1f)
                {
                    canJump = true;
                }
            }
        }
    }

    void OnCollisionStay(Collision collision)
    {
        if (((1 << collision.gameObject.layer) & groundLayer) != 0)
        {
            bool hasGroundContact = false;

            foreach (ContactPoint contact in collision.contacts)
            {
                if (contact.normal.y > 0.5f)
                {
                    hasGroundContact = true;
                    break;
                }
            }

            if (hasGroundContact)
            {
                isOnGround = true;

                if (!canJump && Time.time > lastJumpTime + 0.1f)
                {
                    canJump = true;
                }
            }
        }
    }

    void OnCollisionExit(Collision collision)
    {
        if (((1 << collision.gameObject.layer) & groundLayer) != 0)
        {
            groundContactCount--;
            if (groundContactCount <= 0)
            {
                groundContactCount = 0;
                isOnGround = false;
            }
        }
    }

    void UpdateCamera()
    {
        if (playerCamera != null)
        {
            Vector3 targetPosition = transform.position + cameraOffset;
            playerCamera.transform.position = Vector3.Lerp(
                playerCamera.transform.position,
                targetPosition,
                cameraSmoothSpeed * Time.deltaTime
            );
            playerCamera.transform.LookAt(transform);
        }
    }

    void OnDrawGizmosSelected()
    {
        if (sphereCollider != null)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position, sphereCollider.radius);
        }
    }
}