using UnityEngine;

public class BallRollingWithCamera : MonoBehaviour
{
    [Header("移动参数")]
    public float moveForce = 15f;
    public float maxSpeed = 8f;
    public float jumpForce = 10f;
    
    [Header("跳跃系统")]
    public bool canJump = false;  // 只有碰撞检测到地面才能跳跃
    
    [Header("地面检测")]
    public LayerMask groundLayer = 1;
    
    [Header("相机跟随")]
    public Camera playerCamera;
    public Vector3 cameraOffset = new Vector3(0, 5, -8);
    public float cameraSmoothSpeed = 5f;
    
    private Rigidbody rb;
    private Vector3 moveDirection;
    private SphereCollider sphereCollider;
    private bool isOnGround = false;      // 是否通过碰撞检测到地面
    private int groundContactCount = 0;    // 地面接触点数量
    private float lastJumpTime = 0f;
    
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        sphereCollider = GetComponent<SphereCollider>();
        
        // 配置刚体
        rb.drag = 0.5f;
        rb.angularDrag = 0.5f;
        rb.freezeRotation = false;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        
        // 自动查找相机
        if (playerCamera == null)
            playerCamera = Camera.main;
        
        // 初始状态：假设在地面上
        canJump = true;
        isOnGround = true;
    }
    
    void Update()
    {
        // 获取输入
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        
        // 计算相对于相机的移动方向
        Vector3 cameraForward = playerCamera.transform.forward;
        Vector3 cameraRight = playerCamera.transform.right;
        cameraForward.y = 0;
        cameraRight.y = 0;
        cameraForward.Normalize();
        cameraRight.Normalize();
        
        moveDirection = (cameraForward * vertical + cameraRight * horizontal).normalized;
        
        // 跳跃系统：只有通过碰撞检测确认在地面上才能跳跃
        if (Input.GetButtonDown("Jump"))
        {
            if (canJump && isOnGround)
            {
                Jump();
                Debug.Log("✅ 跳跃执行！(碰撞检测确认在地面)");
            }
            else
            {
                if (!canJump)
                    Debug.Log("❌ 不能跳跃：已经跳跃过，需要等待下次碰撞检测");
                else if (!isOnGround)
                    Debug.Log("❌ 不能跳跃：碰撞检测未检测到地面");
            }
        }
        
        // 更新相机位置
        UpdateCamera();
        
        // 调试信息：显示当前状态
        if (Input.GetKeyDown(KeyCode.F1))
        {
            Debug.Log($"状态 - 可跳跃: {canJump}, 接触地面: {isOnGround}, 接触点数: {groundContactCount}");
        }
    }
    
    void FixedUpdate()
    {
        // 移动
        if (moveDirection != Vector3.zero)
        {
            rb.AddForce(moveDirection * moveForce, ForceMode.Force);
        }
        
        // 限制速度
        Vector3 horizontalVelocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        if (horizontalVelocity.magnitude > maxSpeed)
        {
            horizontalVelocity = horizontalVelocity.normalized * maxSpeed;
            rb.velocity = new Vector3(horizontalVelocity.x, rb.velocity.y, horizontalVelocity.z);
        }
    }
    
    void Jump()
    {
        // 清除Y轴速度，让跳跃更稳定
        rb.velocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        
        // 施加向上的力
        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        
        // 跳跃后重置状态，必须等待下次碰撞才能再次跳跃
        canJump = false;
        isOnGround = false;
        groundContactCount = 0;
        lastJumpTime = Time.time;
        
        Debug.Log($"🚀 跳跃！跳跃时间: {lastJumpTime}");
    }
    
    void OnCollisionEnter(Collision collision)
    {
        // 检查碰撞的物体是否是地面层
        if (((1 << collision.gameObject.layer) & groundLayer) != 0)
        {
            bool hasGroundContact = false;
            
            // 遍历所有接触点，检查是否接触地面
            foreach (ContactPoint contact in collision.contacts)
            {
                // 法线朝上表示球体底部接触
                if (contact.normal.y > 0.5f)
                {
                    hasGroundContact = true;
                    groundContactCount++;
                    Debug.Log($"🟢 碰撞检测到地面！接触点法线: {contact.normal.y:F2}, 接触点数: {groundContactCount}");
                    break;
                }
            }
            
            if (hasGroundContact)
            {
                isOnGround = true;
                
                // 只有在跳跃后才需要重置跳跃能力
                // 防止在空中连续碰撞导致重复重置
                if (!canJump && Time.time > lastJumpTime + 0.1f)
                {
                    canJump = true;
                    Debug.Log("✨ 通过碰撞检测重置跳跃能力！可以再次跳跃 ✨");
                }
            }
        }
    }
    
    void OnCollisionStay(Collision collision)
    {
        // 持续接触地面时保持状态
        if (((1 << collision.gameObject.layer) & groundLayer) != 0)
        {
            bool hasGroundContact = false;
            
            foreach (ContactPoint contact in collision.contacts)
            {
                if (contact.normal.y > 0.5f)
                {
                    hasGroundContact = true;
                    break;
                }
            }
            
            if (hasGroundContact)
            {
                isOnGround = true;
                
                // 确保跳跃能力被重置
                if (!canJump && Time.time > lastJumpTime + 0.1f)
                {
                    canJump = true;
                    Debug.Log("✨ 持续接触中，确保跳跃能力已重置 ✨");
                }
            }
        }
    }
    
    void OnCollisionExit(Collision collision)
    {
        // 离开地面时减少接触计数
        if (((1 << collision.gameObject.layer) & groundLayer) != 0)
        {
            groundContactCount--;
            if (groundContactCount <= 0)
            {
                groundContactCount = 0;
                isOnGround = false;
                Debug.Log("🔴 离开地面，等待下次碰撞检测");
            }
        }
    }
    
    void UpdateCamera()
    {
        if (playerCamera != null)
        {
            Vector3 targetPosition = transform.position + cameraOffset;
            playerCamera.transform.position = Vector3.Lerp(
                playerCamera.transform.position, 
                targetPosition, 
                cameraSmoothSpeed * Time.deltaTime
            );
            playerCamera.transform.LookAt(transform);
        }
    }
    
    void OnDrawGizmosSelected()
    {
        // 可视化球体范围
        if (sphereCollider != null)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(transform.position, sphereCollider.radius);
        }
    }
}