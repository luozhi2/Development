using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class VictoryManager : MonoBehaviour
{
    public static VictoryManager Instance;
    
    [Header("胜利UI")]
    public GameObject victoryPanel;
    public Text victoryText;
    public Button backToMenuButton;
    public Button restartButton;
    
    [Header("胜利效果")]
    public string victoryMessage = "游戏胜利！";
    public bool showVictoryOnWin = true;
    
    private bool isVictory = false;
    
    void Awake()
    {
        // 单例模式：确保只有一个VictoryManager实例
        if (Instance == null)
        {
            Instance = this;
            Debug.Log("VictoryManager已初始化");
        }
        else
        {
            Destroy(gameObject);
            Debug.LogWarning("发现重复的VictoryManager，已删除");
        }
    }
    
    void Start()
    {
        // 确保胜利面板初始隐藏
        if (victoryPanel != null)
        {
            victoryPanel.SetActive(false);
            Debug.Log("胜利面板已设置为隐藏");
        }
        else
        {
            Debug.LogError("VictoryManager: victoryPanel未设置！");
        }
        
        // 绑定按钮事件
        if (backToMenuButton != null)
        {
            backToMenuButton.onClick.AddListener(BackToMainMenu);
            Debug.Log("返回主菜单按钮已绑定");
        }
        else
        {
            Debug.LogError("VictoryManager: backToMenuButton未设置！");
        }
        
        if (restartButton != null)
        {
            restartButton.onClick.AddListener(RestartGame);
            Debug.Log("重新开始按钮已绑定");
        }
        else
        {
            Debug.LogError("VictoryManager: restartButton未设置！");
        }
    }
    
    public void Victory()
    {
        // 防止重复触发胜利
        if (isVictory) 
        {
            Debug.Log("胜利已触发，忽略重复调用");
            return;
        }
        
        isVictory = true;
        
        Debug.Log("🎉 游戏胜利！ 🎉");
        
        if (showVictoryOnWin)
        {
            ShowVictoryScreen();
        }
        
        // 暂停游戏
        Time.timeScale = 0f;
        Debug.Log("游戏时间已暂停");
        
        // 显示鼠标光标
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        Debug.Log("鼠标光标已显示");
    }
    
    void ShowVictoryScreen()
    {
        if (victoryPanel != null)
        {
            victoryPanel.SetActive(true);
            Debug.Log("胜利面板已显示");
            
            // 设置胜利文字
            if (victoryText != null)
            {
                victoryText.text = victoryMessage;
                Debug.Log($"胜利文字已设置: {victoryMessage}");
            }
        }
        else
        {
            Debug.LogError("victoryPanel为空，无法显示胜利界面");
        }
    }
    
    void BackToMainMenu()
    {
        Debug.Log("返回主菜单");
        Time.timeScale = 1f;  // 恢复时间
        SceneManager.LoadScene("MainMenu");
    }
    
    void RestartGame()
    {
        Debug.Log("重新开始游戏");
        Time.timeScale = 1f;  // 恢复时间
        SceneManager.LoadScene("Game");
    }
    
    public bool IsVictory()
    {
        return isVictory;
    }
}